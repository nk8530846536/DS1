public class ImplExample implements Hello{
	public void message() {
		System.out.println("This is at server");
	}
}